import dash
from dash import dcc, html
import plotly.express as px
import pandas as pd

# Load data
df = pd.read_csv('../data/tweets_with_sentiment.csv')

# Initialize the Dash app
app = dash.Dash(__name__)

# Create a figure
fig = px.line(df, x='Created_At', y='Sentiment', title='Sentiment Analysis Over Time')

# Define the layout
app.layout = html.Div(children=[
    html.H1(children='Social Media Sentiment Analysis Dashboard'),
    dcc.Graph(
        id='sentiment-graph',
        figure=fig
    )
])

# Run the app
if __name__ == '__main__':
    app.run_server(debug=True)
