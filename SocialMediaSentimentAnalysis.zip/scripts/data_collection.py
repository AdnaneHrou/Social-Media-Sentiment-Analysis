import tweepy
import pandas as pd

# Add your own credentials obtained 
# from your developer account
consumer_key = 'YOUR_CONSUMER_KEY'
consumer_secret = 'YOUR_CONSUMER_SECRET'
access_token = 'YOUR_ACCESS_TOKEN'
access_token_secret = 'YOUR_ACCESS_TOKEN_SECRET'

# Function to extract tweets
def get_tweets(query, count=100):
    auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
    auth.set_access_token(access_token, access_token_secret)
    api = tweepy.API(auth)
    tweets = api.search(q=query, count=count)
    data = [[tweet.text, tweet.created_at, tweet.user.screen_name] for tweet in tweets]
    df = pd.DataFrame(data, columns=['Text', 'Created_At', 'User'])
    return df

if __name__ == '__main__':
    df = get_tweets('YourTopic', count=200)
    df.to_csv('../data/tweets.csv', index=False)
