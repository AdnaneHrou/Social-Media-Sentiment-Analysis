import pandas as pd
from nltk.sentiment.vader import SentimentIntensityAnalyzer

# Load the dataset
df = pd.read_csv('../data/tweets.csv')

# Initialize the VADER sentiment analyzer
sid = SentimentIntensityAnalyzer()

# Function to analyze sentiment
def analyze_sentiment(text):
    scores = sid.polarity_scores(text)
    return scores['compound']

# Apply sentiment analysis
df['Sentiment'] = df['Text'].apply(analyze_sentiment)
df.to_csv('../data/tweets_with_sentiment.csv', index=False)
